﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OggleGame
{
    public class Player
    {
        string Name;
        string Score;


    }
}
